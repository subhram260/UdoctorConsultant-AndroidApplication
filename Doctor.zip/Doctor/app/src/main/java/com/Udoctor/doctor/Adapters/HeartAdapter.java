package com.Udoctor.doctor.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Udoctor.doctor.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class HeartAdapter extends RecyclerView.Adapter<HeartAdapter.MyViewHolder>{

    Context context;
    ArrayList<HeartDoctor> list;

    public HeartAdapter(Context context, ArrayList<HeartDoctor> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View v = LayoutInflater.from(context).inflate(R.layout.heartitem,parent,false);
       return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HeartAdapter.MyViewHolder holder, int position) {
        HeartDoctor Hdoctor = list.get(position);
//        holder.imageHeart.setImageURI(Hdoctor.getImageHeart().toString());
        Picasso.get().load(Hdoctor.getImageHeart())
                .placeholder(R.drawable.rounded)
                .into(holder.imageHeart);
        holder.nameHeart.setText(Hdoctor.getNameHeart());
        holder.specialHeart.setText(Hdoctor.getSpecialHeart());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView imageHeart;
        TextView nameHeart,specialHeart;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imageHeart=itemView.findViewById(R.id.imageheart);
            nameHeart=itemView.findViewById(R.id.nameHeart);
            specialHeart=itemView.findViewById(R.id.specialHeart);

        }
    }

}
