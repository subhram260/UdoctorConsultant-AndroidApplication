package com.Udoctor.doctor;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;

import com.Udoctor.doctor.R;
import com.google.android.material.navigation.NavigationView;

public class patientHome extends AppCompatActivity {

//    DrawerLayout drawerLayout;
//    NavigationView navigationView;
//    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_home);


//
//        //find view by id
//        drawerLayout=findViewById(R.id.drawer_layout);
//        navigationView=findViewById(R.id.nav_view);
//        toolbar=findViewById(R.id.tool_bar);
//
//        //Toolbar
//        setSupportActionBar(toolbar);
//
//        //navigation drawer
//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.nav_drawer_open,R.string.nav_drawer_close);
//        drawerLayout.addDrawerListener(toggle);
//        toggle.syncState();

    }
}